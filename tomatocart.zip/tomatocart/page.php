<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */

get_header(); ?>
<div id="content-wrapper" class="hfeed site">
	<?php $post_data = $post->post_parent; 
		  $the_parent = get_post($post_data); 	
		  $slug = $the_parent->post_name;
	?>
	<section class="wrapper child-pages <?php echo ($slug=='features')?'features':'';?>">
    	 <?php	
			$post_data = $post->post_parent;
			if (!$post_data==0) { 
				/*$args = array ('child_of'=>$post->ID,'title_li'=>__(''),'link_after'=>'','sort_column'  => 'menu_order');
				$page_childs = get_pages ($args);
				foreach( $page_childs as $page ) {		
				?>
				<li class="<?php echo ($post->ID == $page->ID)?'current': ''; ?>">
					<a href="<?php echo get_page_link( $page->ID ); ?>"><?php echo $page->post_title; ?></a>
				</li>
				<?php }	
			} else {*/
			?>
            <?php
			$args = array ('child_of'=>$post_data,'title_li'=>__(''),'link_after'=>'','sort_column'  => 'menu_order');
  			$page_childs= get_pages ($args);?>
			<ul class="container"> <?php
				foreach( $page_childs as $page ) {
				?>
					<li class="<?php echo ($post->ID == $page->ID)?'current': ''; ?>">
						<a href="<?php echo get_page_link( $page->ID ); ?>"><?php echo $page->post_title; ?></a>
					</li>
				<?php }	?>
			</ul>
		<?php } else { ?>
        	<header class="entry-header container">
				<h1 class="parent entry-title">TomatoCart <?php the_title() ?></h1>
            </header>
		<?php }?>
        
    </section>
	
	<div id="content" class="container clearfix">
        <section id="primary" class="site-content col8">
            <div id="main" role="main">
    
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php //get_template_part( 'content', 'page' ); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    	<?php if (!$post_data==0) : ?>
                            <header class="entry-header">
                                <h1 class="entry-title"><?php the_title(); ?></h1>
                            </header>
               			<?php endif; ?>
                        <div class="entry-content">
                            <?php the_content(); ?>
                            <?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'tomatocart' ), 'after' => '</div>' ) ); ?>
                        </div><!-- .entry-content -->
                        <footer class="entry-meta">
                            <?php edit_post_link( __( 'Edit', 'tomatocart' ), '<span class="edit-link">', '</span>' ); ?>
                        </footer><!-- .entry-meta -->
                    </article><!-- #post -->
                <?php endwhile; // end of the loop. ?>
    
            </div><!-- #content -->
        </section><!-- #primary -->
        <?php get_sidebar(); ?>
    </div><!-- #main .wrapper -->
</div><!-- #page -->

<?php get_footer(); ?>