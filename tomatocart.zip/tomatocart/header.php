<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php // Loads HTML5 JavaScript file to add support for HTML5 elements in older IE versions. ?>
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<header id="header" class="wrapper clearfix"> 
    <div class="header container clearfix">
        <div class="col3">
            <hgroup >
                <h1 id="site-title"><a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><img src="<?php echo get_template_directory_uri().'/images/logo.png';?>" title="<?php bloginfo( 'name' ); ?>"/></a></h1>
                <h2 id="site-description"><?php bloginfo( 'description' ); ?></h2>
            </hgroup>
        </div>
        <div class="col9">
        	<div id="top-nav" class="clearfix">
             	<ul id="social-links" class="clearfix">
                	<li class="social-link">
                    	<a href="" class="facebook"><i class="facebook"></i>Facebook</a>
                    </li>
                    <li class="twitter">
                    	<a href="" class="twitter"><i class="twitter"></i>Twitter</a>
                    </li>
                </ul>
            	<?php wp_nav_menu( array( 'theme_location' => 'top-menu', 'menu_class' => 'top-menu','container'=> '' ) ); ?> 
               
            </div>
            <nav id="main-nav" role="navigation" class="clearfix">
                <a class="assistive-text" href="#content" title="<?php esc_attr_e( 'Skip to content', 'tomatocart' ); ?>"><?php _e( 'Skip to content', 'tomatocart' ); ?></a>
                 <div class="download-btn">   
                	<a href="#" class="button"><?php _e( 'Download', 'tomatocart' ); ?> <i class="download"></i></a>
                </div>
                <?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu','container'=> '' ) ); ?> 
               
            </nav><!-- #site-navigation -->
        </div>
    </div>
</header><!-- #masthead -->
