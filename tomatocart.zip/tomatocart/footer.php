<?php
/**
 * The template for displaying the footer.
 *
 * Contains footer content and the closing of the
 * #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
<section id="call-to-action">
	<div class="container">
    </div>
</section>
<footer class="footer wrapper clearfix" role="contentinfo">

	<div id="footer" class="container">
    	<div class="latests clearfix">
        
    	</div>
        <div class="additional clearfix">
        	<div class="col5">
            	<?php if ( is_active_sidebar( 'footer-left' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-left' ); ?>
                <?php endif; ?>
            </div>
            <div class="col4">
                <?php if ( is_active_sidebar( 'footer-middle' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-middle' ); ?>
                <?php endif; ?>
            </div>
            <div class="col3">
                <?php if ( is_active_sidebar( 'footer-right' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-right' ); ?>
                <?php endif; ?>
            </div>
    	</div>
        <div class="sitemap clearfix">
			<div class="left col8">
            	<div class="menu widget">
                	<h3 class="widget-title"><?php _e( 'Features', 'tomatocart' ); ?></h3>
                    <?php wp_nav_menu( array( 'theme_location' => 'features-menu', 'menu_class' => 'features-menu','container'=> '' ) ); ?> 
                	
                </div>
                <div class="menu">
                	<h3 class="widget-title"><?php _e( 'Resources', 'tomatocart' ); ?></h3>
                	<?php wp_nav_menu( array( 'theme_location' => 'resources-menu', 'menu_class' => 'resources-menu','container'=> '' ) ); ?> 
                    <h3 class="widget-title"><?php _e( 'Documentation', 'tomatocart' ); ?></h3>
                    <?php wp_nav_menu( array( 'theme_location' => 'documentation-menu', 'menu_class' => 'documentation-menu','container'=> '' ) ); ?> 
                </div> 
                <div class="menu">
                	<h3 class="widget-title"><?php _e( 'Support', 'tomatocart' ); ?></h3>
                	<?php wp_nav_menu( array( 'theme_location' => 'support-menu', 'menu_class' => 'support-menu','container'=> '' ) ); ?> 
                    <h3 class="widget-title"><?php _e( 'Partners', 'tomatocart' ); ?></h3>
                    <?php wp_nav_menu( array( 'theme_location' => 'partners-menu', 'menu_class' => 'partners-menu','container'=> '' ) ); ?> 
                </div>
                <div class="menu">
                	<h3 class="widget-title"><?php _e( 'More about us', 'tomatocart' ); ?></h3>
                	<?php wp_nav_menu( array( 'theme_location' => 'about-menu', 'menu_class' => 'support-menu','container'=> '' ) ); ?> 
                    <h3 class="widget-title"><?php _e( 'Get Social', 'tomatocart' ); ?></h3>
                    <?php wp_nav_menu( array( 'theme_location' => 'social-menu', 'menu_class' => 'partners-menu','container'=> '' ) ); ?> 
                </div>
            </div>
            <div class="col4 no-margin stats">
            	<div class="row">
                	<div class="col6 number">
                    	<span class="">
                        	126.540
                        </span>
                    </div>
                    <div class="col6">
                    	<span class="text">
                        	Downloaded <br /> 
                            <span class="small">Tomatocart</span>
                        </span>
                    </div>
                </div>
                <div class="row">
                	<div class="col6 number">
                    	<span class="">
                        	67.613
                        </span>
                    </div>
                    <div class="col6">
                    	<span class="text">
                        	Registred <br /> 
                            <span class="small">Comunity Users</span>
                        </span>
                    </div>
                </div>
                <div class="row">
                	<div class="col6 number">
                    	<span class="">
                        	24.343
                        </span>
                    </div>
                    <div class="col6">
                    	<span class="text">
                        	Forum <br /> 
                            <span class="small">Discussions</span>
                        </span>
                    </div>
                </div>
            </div>
    	</div>
    </div>
    
</footer>


<?php wp_footer(); ?>
</body>
</html>