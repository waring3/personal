<?php
/**
 * Template Name: Home Page Template
 */

get_header(); ?>

<div id="content-wrapper" class="hfeed site">
		<div id="content" role="main">

			<?php while ( have_posts() ) : the_post(); ?>
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="entry-page-image">
						<?php the_post_thumbnail(); ?>
					</div><!-- .entry-page-image -->
				<?php endif; ?>

			<?php endwhile; // end of the loop. ?>

		</div><!-- #content -->
</div>
<?php get_footer(); ?>